package snippet;

public class Snippet {
	public static void main(String[] args) {
		orgWeights.get(i,1))[0]
	}
}

